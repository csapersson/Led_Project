//
//  AboutViewController.h
//  Led_Proj
//
//  Created by Simon Persson on 2017-01-27.
//  Copyright © 2017 Simon Persson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController {
 
    IBOutlet UITextView *textView;
}

@end
